require 'mkmf'
create_makefile('cron')
